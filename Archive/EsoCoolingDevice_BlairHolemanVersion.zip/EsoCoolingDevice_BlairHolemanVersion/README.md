#Temperature Measuring Device

See pictures of circuit in Pics folder, the LEDs are for debugging.